"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function ServerLoginPage() {
  const [email, setEmail] = useState("john@example.com")
  const [password, setPassword] = useState("password123")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [debug, setDebug] = useState<any>(null)
  const [success, setSuccess] = useState(false)

  const handleServerLogin = async () => {
    setLoading(true)
    setError("")
    setDebug(null)
    setSuccess(false)

    try {
      // Call the server-side API route
      const response = await fetch("/api/direct-auth", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Authentication failed")
      }

      setDebug(data)
      setSuccess(true)

      // Reload the page to ensure the session is picked up
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    } catch (err: any) {
      console.error("Server login error:", err)
      setError(err.message || "Failed to log in")
    } finally {
      setLoading(false)
    }
  }

  const goToDashboard = () => {
    window.location.href = "/simple-dashboard"
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Server-Side Login</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 bg-green-100 text-green-800">
              <AlertDescription>Login successful! You can now go to the dashboard.</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="john@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password123"
            />
          </div>

          <Button className="w-full" onClick={handleServerLogin} disabled={loading}>
            {loading ? "Processing..." : "Login with Server"}
          </Button>

          {success && (
            <Button className="w-full" onClick={goToDashboard}>
              Go to Dashboard
            </Button>
          )}

          {debug && (
            <div className="mt-4 p-2 bg-gray-100 rounded-md">
              <p className="text-sm font-bold">Debug Info:</p>
              <pre className="text-xs overflow-auto max-h-40">{JSON.stringify(debug, null, 2)}</pre>
            </div>
          )}

          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">How this works:</p>
            <ul className="text-xs text-muted-foreground space-y-1 list-disc pl-4">
              <li>This page uses a server-side API route for authentication</li>
              <li>The server has higher permissions and can create users if needed</li>
              <li>If the user doesn't exist, it will be created automatically</li>
              <li>After login, the session will be established in your browser</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
