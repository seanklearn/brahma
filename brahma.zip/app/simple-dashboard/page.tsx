"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createBrowserClient } from "@/lib/supabase"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"

export default function SimpleDashboardPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [showLogin, setShowLogin] = useState(false)
  const [email, setEmail] = useState("john@example.com")
  const [password, setPassword] = useState("password123")
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginError, setLoginError] = useState("")
  const [sessionDebug, setSessionDebug] = useState<any>(null)
  const supabase = createBrowserClient()

  useEffect(() => {
    const getUser = async () => {
      try {
        // First check if we have a session
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

        if (sessionError) {
          console.error("Session error:", sessionError)
          setError("Failed to get session: " + sessionError.message)
          setLoading(false)
          return
        }

        setSessionDebug(sessionData)

        if (!sessionData.session) {
          setError("No active session found. Please log in.")
          setLoading(false)
          return
        }

        // Get the current user
        const { data: userData, error: userError } = await supabase.auth.getUser()

        if (userError) {
          console.error("User error:", userError)
          setError("Failed to get user: " + userError.message)
          setLoading(false)
          return
        }

        if (!userData.user) {
          setError("No user found in the session. Please log in again.")
          setLoading(false)
          return
        }

        setUser(userData.user)

        // Get the user's profile
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", userData.user.id)
          .single()

        if (profileError) {
          console.error("Profile error:", profileError)
          // Don't throw here, we can still show the user info
        } else {
          setProfile(profileData)
        }
      } catch (err: any) {
        console.error("Error fetching user:", err)
        setError(err.message || "Failed to load user data")
      } finally {
        setLoading(false)
      }
    }

    getUser()
  }, [supabase])

  const handleLogin = async () => {
    setLoginLoading(true)
    setLoginError("")

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      // Reload the page to refresh the session
      window.location.reload()
    } catch (err: any) {
      console.error("Login error:", err)
      setLoginError(err.message || "Failed to log in")
    } finally {
      setLoginLoading(false)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    window.location.reload()
  }

  const createTestUser = async () => {
    setLoginLoading(true)
    setLoginError("")

    try {
      // Call the API route to create a test user
      const response = await fetch(
        `/api/create-test-user?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
      )
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create test user")
      }

      // Try to log in with the newly created user
      await handleLogin()
    } catch (err: any) {
      console.error("Error creating test user:", err)
      setLoginError(err.message || "Failed to create test user")
    } finally {
      setLoginLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-6 text-center">
            <p>Loading user data...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error || !user) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error || "Not authenticated"}</AlertDescription>
            </Alert>

            {sessionDebug && (
              <div className="mb-4 p-2 bg-gray-100 rounded-md">
                <p className="text-sm font-bold">Session Debug:</p>
                <pre className="text-xs overflow-auto max-h-40">{JSON.stringify(sessionDebug, null, 2)}</pre>
              </div>
            )}

            {showLogin ? (
              <div className="space-y-4">
                {loginError && (
                  <Alert variant="destructive">
                    <AlertDescription>{loginError}</AlertDescription>
                  </Alert>
                )}
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="john@example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="password123"
                  />
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1" onClick={handleLogin} disabled={loginLoading}>
                    {loginLoading ? "Logging in..." : "Log In"}
                  </Button>
                  <Button className="flex-1" variant="outline" onClick={createTestUser} disabled={loginLoading}>
                    Create & Login
                  </Button>
                </div>
                <Button variant="ghost" onClick={() => setShowLogin(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <p>You need to be logged in to view this page.</p>
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => setShowLogin(true)}>Log In Now</Button>
                  <Button asChild variant="outline">
                    <Link href="/login-direct">Go to Login Page</Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link href="/server-login">Server Login</Link>
                  </Button>
                  <Button asChild variant="secondary">
                    <Link href="/simple-home">Back to Home</Link>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>Simple Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-lg font-bold mb-2">Your Account</h3>
            <div className="bg-gray-100 p-4 rounded-md">
              <p>
                <strong>Email:</strong> {user.email}
              </p>
              <p>
                <strong>User ID:</strong> {user.id}
              </p>
              <p>
                <strong>Last Sign In:</strong> {new Date(user.last_sign_in_at).toLocaleString()}
              </p>
            </div>
          </div>

          {profile && (
            <div>
              <h3 className="text-lg font-bold mb-2">Your Profile</h3>
              <div className="bg-gray-100 p-4 rounded-md">
                <p>
                  <strong>Username:</strong> {profile.username}
                </p>
                <p>
                  <strong>Name:</strong> {profile.name}
                </p>
                {profile.bio && (
                  <p>
                    <strong>Bio:</strong> {profile.bio}
                  </p>
                )}
                {profile.tagline && (
                  <p>
                    <strong>Tagline:</strong> {profile.tagline}
                  </p>
                )}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-wrap gap-4">
          <Button asChild>
            <Link href="/dashboard">Go to Full Dashboard</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/simple-edit">Edit Profile</Link>
          </Button>
          <Button variant="destructive" onClick={handleSignOut}>
            Sign Out
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
