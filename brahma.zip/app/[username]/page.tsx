import { ProfileHeader } from "@/components/profile-header"
import { SocialLink } from "@/components/social-link"
import { Instagram, Linkedin, TiktokIcon } from "@/components/social-icons"
import { notFound } from "next/navigation"
import { getUserByUsername } from "@/lib/auth"

const platformIcons: Record<string, any> = {
  instagram: Instagram,
  tiktok: TiktokIcon,
  linkedin: Linkedin,
}

const platformStyles: Record<string, string> = {
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 hover:from-purple-600 hover:to-pink-600",
  tiktok: "bg-black text-white border-0 hover:bg-gray-800",
  linkedin: "bg-blue-600 text-white border-0 hover:bg-blue-700",
  snapchat: "bg-yellow-400 text-black border-0 hover:bg-yellow-500",
  custom: "bg-gray-200 dark:bg-gray-700",
}

// List of reserved usernames that should not be treated as profile pages
const RESERVED_ROUTES = ["login", "signup", "edit", "demo", "api", "_next", "favicon.ico", "dashboard", "auth", "demo"]

interface ProfilePageProps {
  params: {
    username: string
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { username } = params

  // Check if this is a reserved route
  if (RESERVED_ROUTES.includes(username)) {
    notFound()
  }

  const user = await getUserByUsername(username)

  if (!user) {
    notFound()
  }

  return (
    <div className="flex flex-col min-h-screen items-center p-4 md:p-8">
      <div className="w-full max-w-md mx-auto py-8 space-y-8">
        <ProfileHeader
          username={user.username}
          name={user.name}
          bio={user.bio || ""}
          tagline={user.tagline || ""}
          avatarUrl={user.avatar_url || "/placeholder.svg?height=96&width=96"}
        />

        <div className="space-y-4">
          {user.links &&
            user.links.map((link: any, index: number) => (
              <SocialLink
                key={index}
                href={link.url}
                icon={platformIcons[link.platform] || Instagram}
                label={link.label}
                className={platformStyles[link.platform] || platformStyles.custom}
              />
            ))}
        </div>

        <div className="pt-8 text-center">
          <p className="text-xs text-muted-foreground">
            Powered by <span className="font-bold">Brahma</span>
          </p>
        </div>
      </div>
    </div>
  )
}
