"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createBrowserClient } from "@/lib/supabase"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function AuthStatusPage() {
  const [status, setStatus] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [serverStatus, setServerStatus] = useState<any>(null)
  const [serverLoading, setServerLoading] = useState(true)
  const [email, setEmail] = useState("john@example.com")
  const [password, setPassword] = useState("password123")
  const [loginLoading, setLoginLoading] = useState(false)
  const [loginError, setLoginError] = useState("")
  const supabase = createBrowserClient()

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Get session
        const { data: sessionData } = await supabase.auth.getSession()

        // Get user
        const { data: userData } = await supabase.auth.getUser()

        setStatus({
          session: sessionData,
          user: userData,
          timestamp: new Date().toISOString(),
        })
      } catch (err) {
        console.error("Error checking auth:", err)
        setStatus({
          error: String(err),
          timestamp: new Date().toISOString(),
        })
      } finally {
        setLoading(false)
      }
    }

    const checkServerAuth = async () => {
      try {
        const response = await fetch("/api/auth-check")
        const data = await response.json()
        setServerStatus(data)
      } catch (err) {
        console.error("Error checking server auth:", err)
        setServerStatus({
          error: String(err),
          timestamp: new Date().toISOString(),
        })
      } finally {
        setServerLoading(false)
      }
    }

    checkAuth()
    checkServerAuth()
  }, [supabase])

  const handleRefresh = () => {
    setLoading(true)
    setServerLoading(true)
    window.location.reload()
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    window.location.reload()
  }

  const handleLogin = async () => {
    setLoginLoading(true)
    setLoginError("")

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) throw error

      // Reload the page to refresh the session
      window.location.reload()
    } catch (err: any) {
      console.error("Login error:", err)
      setLoginError(err.message || "Failed to log in")
      setLoginLoading(false)
    }
  }

  const createTestUser = async () => {
    setLoginLoading(true)
    setLoginError("")

    try {
      // Call the API route to create a test user
      const response = await fetch(
        `/api/create-test-user?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
      )
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create test user")
      }

      // Try to log in with the newly created user
      await handleLogin()
    } catch (err: any) {
      console.error("Error creating test user:", err)
      setLoginError(err.message || "Failed to create test user")
      setLoginLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Authentication Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {(loading || serverLoading) && <p>Checking authentication status...</p>}

          {!loading && !status?.session?.session && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>You are not authenticated. Please log in.</AlertDescription>
            </Alert>
          )}

          {loginError && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{loginError}</AlertDescription>
            </Alert>
          )}

          {!status?.session?.session && (
            <div className="space-y-4 border p-4 rounded-lg">
              <h3 className="text-lg font-bold">Quick Login</h3>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="password123"
                />
              </div>
              <div className="flex gap-2">
                <Button className="flex-1" onClick={handleLogin} disabled={loginLoading}>
                  {loginLoading ? "Logging in..." : "Log In"}
                </Button>
                <Button className="flex-1" variant="outline" onClick={createTestUser} disabled={loginLoading}>
                  Create & Login
                </Button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Client-Side Status:</h3>
            <div className="bg-gray-100 p-4 rounded-md overflow-auto max-h-96">
              <pre>{JSON.stringify(status, null, 2)}</pre>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Server-Side Status:</h3>
            <div className="bg-gray-100 p-4 rounded-md overflow-auto max-h-96">
              <pre>{JSON.stringify(serverStatus, null, 2)}</pre>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-bold">Troubleshooting:</h3>
            <ul className="list-disc pl-5 space-y-2">
              <li>If you see "No active session" in both statuses, you need to log in</li>
              <li>If client-side shows a session but server-side doesn't, there might be a cookie issue</li>
              <li>Try using the "Create & Login" button to create a test user and log in</li>
              <li>After logging in, click "Refresh Status" to check if the session is properly set</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="flex flex-wrap gap-4">
          <Button onClick={handleRefresh}>Refresh Status</Button>

          {status?.session?.session && (
            <Button variant="destructive" onClick={handleSignOut}>
              Sign Out
            </Button>
          )}

          <Button asChild variant="outline">
            <Link href="/simple-home">Go to Simple Home</Link>
          </Button>

          <Button asChild variant="outline">
            <Link href="/login-direct">Go to Direct Login</Link>
          </Button>

          <Button asChild variant="outline">
            <Link href="/server-login">Go to Server Login</Link>
          </Button>

          {status?.session?.session && (
            <>
              <Button asChild>
                <Link href="/simple-dashboard">Go to Simple Dashboard</Link>
              </Button>

              <Button asChild>
                <Link href="/simple-edit">Go to Simple Edit</Link>
              </Button>
            </>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
