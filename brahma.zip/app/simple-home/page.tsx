import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function SimpleHomePage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-3xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-6">Brahma - Simple Mode</h1>
        <p className="text-xl mb-8">This is a simplified version of Brahma to help you get past the login page.</p>

        <div className="p-6 border rounded-lg bg-red-50 mb-6">
          <h2 className="text-2xl font-bold mb-4 text-red-700">Important: Login First!</h2>
          <p className="mb-4 text-red-700">
            You must log in before trying to access the dashboard or edit pages. Follow these steps:
          </p>
          <ol className="text-left list-decimal pl-8 mb-4 text-red-700">
            <li>Go to the Server Login page first</li>
            <li>Log in with the sample credentials</li>
            <li>After successful login, then go to the dashboard</li>
          </ol>
          <Button asChild size="lg" className="bg-red-600 hover:bg-red-700">
            <Link href="/server-login">Start Here: Go to Server Login</Link>
          </Button>
        </div>

        <div className="space-y-4">
          <div className="p-6 border rounded-lg bg-gray-50">
            <h2 className="text-2xl font-bold mb-4">Step 1: Login Options</h2>
            <p className="mb-4">Choose one of these login methods:</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button asChild size="lg" variant="default">
                <Link href="/server-login">Server Login (Recommended)</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/login-direct">Direct Login</Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <Link href="/auth-status">Check Auth Status</Link>
              </Button>
            </div>
          </div>

          <div className="p-6 border rounded-lg bg-gray-50">
            <h2 className="text-2xl font-bold mb-4">Step 2: After Login</h2>
            <p className="mb-4">After logging in, you can access these pages:</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button asChild variant="outline">
                <Link href="/simple-dashboard">Simple Dashboard</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/simple-edit">Simple Edit Profile</Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <p className="text-sm text-muted-foreground">
            Once these pages are working, you can try the regular pages again.
          </p>
        </div>
      </div>
    </div>
  )
}
