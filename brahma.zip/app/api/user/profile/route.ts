import { type NextRequest, NextResponse } from "next/server"
import { auth, getUserById, updateUserProfile } from "@/lib/auth"

export async function GET() {
  const session = await auth()

  if (!session?.user?.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  const user = await getUserById(session.user.id)

  if (!user) {
    return NextResponse.json({ message: "User not found" }, { status: 404 })
  }

  return NextResponse.json(user)
}

export async function PUT(request: NextRequest) {
  const session = await auth()

  if (!session?.user?.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  try {
    const { name, bio, avatarUrl } = await request.json()

    const updatedUser = await updateUserProfile(session.user.id, {
      name,
      bio,
      avatarUrl,
    })

    if (!updatedUser) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    return NextResponse.json(updatedUser)
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}
