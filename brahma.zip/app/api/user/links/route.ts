import { type NextRequest, NextResponse } from "next/server"
import { auth, getUserById, updateUserLinks } from "@/lib/auth"

export async function GET() {
  const session = await auth()

  if (!session?.user?.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  const user = await getUserById(session.user.id)

  if (!user) {
    return NextResponse.json({ message: "User not found" }, { status: 404 })
  }

  return NextResponse.json(user.links)
}

export async function PUT(request: NextRequest) {
  const session = await auth()

  if (!session?.user?.id) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
  }

  try {
    const links = await request.json()

    const updatedUser = await updateUserLinks(session.user.id, links)

    if (!updatedUser) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    return NextResponse.json(updatedUser.links)
  } catch (error) {
    console.error("Update links error:", error)
    return NextResponse.json({ message: "Something went wrong" }, { status: 500 })
  }
}
