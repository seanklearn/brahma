import { createServerClient } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const url = new URL(request.url)
  const email = url.searchParams.get("email") || "seanklearn@gmail.com"
  const password = url.searchParams.get("password") || "password123"
  const username = email.split("@")[0]
  const name = username.charAt(0).toUpperCase() + username.slice(1)

  const supabase = createServerClient()

  try {
    // Check if user already exists
    const { data: existingUser } = await supabase.auth.admin.getUserByEmail(email)

    if (existingUser) {
      return NextResponse.json({
        message: "User already exists",
        user: {
          id: existingUser.user.id,
          email: existingUser.user.email,
          username: username,
        },
      })
    }

    // Create user in auth.users
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email: email,
      password: password,
      email_confirm: true,
      user_metadata: {
        name: name,
        username: username,
      },
    })

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 500 })
    }

    // Create profile for user
    const { error: profileError } = await supabase.from("profiles").insert({
      id: authUser.user.id,
      username: username,
      name: name,
      bio: "This is a test account created for demonstration purposes.",
      tagline: "Test Account",
      avatar_url: "/placeholder.svg?height=96&width=96",
    })

    if (profileError) {
      // If profile creation fails, delete the user
      await supabase.auth.admin.deleteUser(authUser.user.id)
      return NextResponse.json({ error: profileError.message }, { status: 500 })
    }

    // Create default links
    const defaultLinks = [
      {
        user_id: authUser.user.id,
        platform: "instagram",
        url: `https://instagram.com/${username}`,
        label: "Instagram",
        display_order: 0,
      },
      {
        user_id: authUser.user.id,
        platform: "tiktok",
        url: `https://tiktok.com/@${username}`,
        label: "TikTok",
        display_order: 1,
      },
      {
        user_id: authUser.user.id,
        platform: "linkedin",
        url: `https://linkedin.com/in/${username}`,
        label: "LinkedIn",
        display_order: 2,
      },
    ]

    const { error: linksError } = await supabase.from("links").insert(defaultLinks)

    if (linksError) {
      return NextResponse.json({ error: linksError.message }, { status: 500 })
    }

    return NextResponse.json({
      message: "User created successfully",
      user: {
        id: authUser.user.id,
        email: authUser.user.email,
        username: username,
      },
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
