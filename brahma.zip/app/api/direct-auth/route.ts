import { createServerClient } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const supabase = createServerClient()

    // Try to sign in
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      // If login fails, check if it's because the user doesn't exist
      if (error.message.includes("Invalid login credentials")) {
        // Try to create the user
        const username = email.split("@")[0]
        const name = username.charAt(0).toUpperCase() + username.slice(1)

        const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            name,
            username,
          },
        })

        if (createError) {
          return NextResponse.json({ error: createError.message }, { status: 500 })
        }

        // Create profile for the new user
        const { error: profileError } = await supabase.from("profiles").insert({
          id: newUser.user.id,
          username,
          name,
          bio: "This is a test account created for demonstration purposes.",
          avatar_url: "/placeholder.svg?height=96&width=96",
        })

        if (profileError) {
          // If profile creation fails, delete the user
          await supabase.auth.admin.deleteUser(newUser.user.id)
          return NextResponse.json({ error: profileError.message }, { status: 500 })
        }

        // Now try to sign in with the newly created user
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (signInError) {
          return NextResponse.json({ error: signInError.message }, { status: 401 })
        }

        return NextResponse.json({
          message: "User created and signed in successfully",
          user: newUser.user,
          session: {
            ...signInData.session,
            access_token: "[REDACTED]",
            refresh_token: "[REDACTED]",
          },
        })
      }

      return NextResponse.json({ error: error.message }, { status: 401 })
    }

    // Return the session and user
    return NextResponse.json({
      message: "Signed in successfully",
      user: data.user,
      session: {
        ...data.session,
        access_token: "[REDACTED]",
        refresh_token: "[REDACTED]",
      },
    })
  } catch (error: any) {
    console.error("Direct auth error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
