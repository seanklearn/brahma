import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const cookieStore = cookies()
    const supabase = createServerClient()

    // Get the session
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

    if (sessionError) {
      return NextResponse.json({ error: sessionError.message }, { status: 500 })
    }

    if (!sessionData.session) {
      return NextResponse.json({ authenticated: false, message: "No active session" })
    }

    // Get the user
    const { data: userData, error: userError } = await supabase.auth.getUser()

    if (userError) {
      return NextResponse.json({ error: userError.message }, { status: 500 })
    }

    // Get the user's profile
    const { data: profileData, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userData.user.id)
      .single()

    // Return the authentication status
    return NextResponse.json({
      authenticated: true,
      user: userData.user,
      profile: profileData || null,
      profileError: profileError ? profileError.message : null,
      session: {
        expires_at: sessionData.session.expires_at,
        // Don't include the actual tokens
        access_token: "[REDACTED]",
        refresh_token: "[REDACTED]",
      },
      cookies: {
        names: Array.from(cookieStore.getAll()).map((cookie) => cookie.name),
      },
    })
  } catch (error: any) {
    console.error("Auth check error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
