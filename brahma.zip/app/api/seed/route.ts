import { createServerClient } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function GET() {
  const supabase = createServerClient()

  try {
    // Sample user data
    const sampleUsers = [
      {
        email: "john@example.com",
        password: "password123",
        username: "johndoe",
        name: "John Doe",
        bio: "Photographer and travel enthusiast. Capturing moments around the world.",
        tagline: "Travel | Photography | Adventure",
        avatar_url: "/diverse-group.png",
        links: [
          { platform: "instagram", url: "https://instagram.com/johndoe", label: "Instagram" },
          { platform: "tiktok", url: "https://tiktok.com/@johndoe", label: "TikTok" },
          { platform: "snapchat", url: "https://snapchat.com/add/johndoe", label: "Snapchat" },
          { platform: "custom", url: "https://johndoe.com", label: "My Portfolio" },
        ],
      },
      {
        email: "jane@example.com",
        password: "password123",
        username: "janedoe",
        name: "Jane Doe",
        bio: "Digital artist and illustrator. Creating colorful worlds one pixel at a time.",
        tagline: "Digital Artist | Illustrator",
        avatar_url: "/diverse-woman-portrait.png",
        links: [
          { platform: "instagram", url: "https://instagram.com/janedoe", label: "Instagram" },
          { platform: "tiktok", url: "https://tiktok.com/@janedoe", label: "TikTok" },
          { platform: "linkedin", url: "https://linkedin.com/in/janedoe", label: "LinkedIn" },
          { platform: "custom", url: "https://behance.net/janedoe", label: "Behance Portfolio" },
          { platform: "custom", url: "https://dribbble.com/janedoe", label: "Dribbble" },
        ],
      },
      {
        email: "tech@example.com",
        password: "password123",
        username: "techguru",
        name: "Tech Guru",
        bio: "Software developer and tech enthusiast. Sharing coding tips and tech reviews.",
        tagline: "Code | Tech | Reviews",
        avatar_url: "/developer-working.png",
        links: [
          { platform: "linkedin", url: "https://linkedin.com/in/techguru", label: "LinkedIn" },
          { platform: "custom", url: "https://github.com/techguru", label: "GitHub" },
          { platform: "custom", url: "https://techguru.dev", label: "My Blog" },
          { platform: "custom", url: "https://youtube.com/c/techguru", label: "YouTube Channel" },
        ],
      },
      {
        email: "fitness@example.com",
        password: "password123",
        username: "fitnessjunkie",
        name: "Fitness Junkie",
        bio: "Personal trainer and nutrition coach. Helping you achieve your fitness goals.",
        tagline: "Fitness | Nutrition | Wellness",
        avatar_url: "/diverse-fitness-group.png",
        links: [
          { platform: "instagram", url: "https://instagram.com/fitnessjunkie", label: "Instagram" },
          { platform: "tiktok", url: "https://tiktok.com/@fitnessjunkie", label: "TikTok" },
          { platform: "snapchat", url: "https://snapchat.com/add/fitnessjunkie", label: "Snapchat" },
          { platform: "custom", url: "https://fitnessjunkie.com", label: "Workout Programs" },
          { platform: "custom", url: "https://fitnessjunkie.com/nutrition", label: "Nutrition Plans" },
        ],
      },
      {
        email: "food@example.com",
        password: "password123",
        username: "foodielover",
        name: "Foodie Lover",
        bio: "Food blogger and home chef. Sharing delicious recipes and restaurant reviews.",
        tagline: "Food | Recipes | Reviews",
        avatar_url: "/diverse-chef-preparing-food.png",
        links: [
          { platform: "instagram", url: "https://instagram.com/foodielover", label: "Instagram" },
          { platform: "tiktok", url: "https://tiktok.com/@foodielover", label: "TikTok" },
          { platform: "custom", url: "https://foodielover.com", label: "My Food Blog" },
          { platform: "custom", url: "https://youtube.com/c/foodielover", label: "Recipe Videos" },
        ],
      },
    ]

    const createdUsers = []

    // Process each sample user
    for (const userData of sampleUsers) {
      // Check if user already exists
      const { data: existingUser } = await supabase
        .from("profiles")
        .select("id")
        .eq("username", userData.username)
        .single()

      if (existingUser) {
        console.log(`User ${userData.username} already exists, skipping...`)
        continue
      }

      // Create user in auth.users
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email: userData.email,
        password: userData.password,
        email_confirm: true,
        user_metadata: {
          name: userData.name,
          username: userData.username,
        },
      })

      if (authError) {
        console.error(`Error creating user ${userData.username}:`, authError)
        continue
      }

      // Create profile for user
      const { error: profileError } = await supabase.from("profiles").insert({
        id: authUser.user.id,
        username: userData.username,
        name: userData.name,
        bio: userData.bio,
        tagline: userData.tagline,
        avatar_url: userData.avatar_url,
      })

      if (profileError) {
        console.error(`Error creating profile for ${userData.username}:`, profileError)
        // If profile creation fails, delete the user
        await supabase.auth.admin.deleteUser(authUser.user.id)
        continue
      }

      // Create links for user
      const linksToInsert = userData.links.map((link, index) => ({
        user_id: authUser.user.id,
        platform: link.platform,
        url: link.url,
        label: link.label,
        display_order: index,
      }))

      const { error: linksError } = await supabase.from("links").insert(linksToInsert)

      if (linksError) {
        console.error(`Error creating links for ${userData.username}:`, linksError)
      }

      createdUsers.push(userData.username)
    }

    return NextResponse.json({
      message: "Seeding completed successfully",
      created_users: createdUsers,
    })
  } catch (error: any) {
    console.error("Error seeding database:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
