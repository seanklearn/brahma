import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { name, username, email, password, userId } = await request.json()

    // Validate input
    if (!name || !username || !email) {
      return NextResponse.json({ message: "Missing required fields" }, { status: 400 })
    }

    const supabase = createServerClient()

    // Check if username is already taken
    const { data: existingUser, error: checkError } = await supabase
      .from("profiles")
      .select("username")
      .eq("username", username)
      .maybeSingle()

    if (checkError) {
      console.error("Error checking username:", checkError)
      return NextResponse.json({ message: "Error checking username" }, { status: 500 })
    }

    if (existingUser) {
      return NextResponse.json({ message: "Username already taken" }, { status: 409 })
    }

    let user_id = userId

    // If userId is not provided, create the user with the admin API
    if (!userId && password) {
      // Create user with email confirmation set to true
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true, // This is the key part - automatically confirm the email
        user_metadata: {
          name,
          username,
        },
      })

      if (authError) {
        console.error("Error creating user:", authError)
        return NextResponse.json({ message: authError.message }, { status: 500 })
      }

      user_id = authUser.user.id
    }

    if (!user_id) {
      return NextResponse.json({ message: "Failed to create or identify user" }, { status: 500 })
    }

    // Create profile for user
    const { error: profileError } = await supabase.from("profiles").insert({
      id: user_id,
      username,
      name,
      bio: "",
      tagline: "",
      avatar_url: "/placeholder.svg?height=96&width=96",
    })

    if (profileError) {
      console.error("Error creating profile:", profileError)
      // If profile creation fails, delete the user
      if (!userId) {
        await supabase.auth.admin.deleteUser(user_id)
      }
      return NextResponse.json({ message: "Failed to create profile" }, { status: 500 })
    }

    // Create default links
    const defaultLinks = [
      {
        user_id: user_id,
        platform: "instagram",
        url: `https://instagram.com/${username}`,
        label: "Instagram",
        display_order: 0,
      },
      {
        user_id: user_id,
        platform: "tiktok",
        url: `https://tiktok.com/@${username}`,
        label: "TikTok",
        display_order: 1,
      },
      {
        user_id: user_id,
        platform: "linkedin",
        url: `https://linkedin.com/in/${username}`,
        label: "LinkedIn",
        display_order: 2,
      },
    ]

    const { error: linksError } = await supabase.from("links").insert(defaultLinks)

    if (linksError) {
      console.error("Error creating links:", linksError)
      // Don't fail the whole signup if links creation fails
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user_id,
        name,
        email,
        username,
      },
    })
  } catch (error: any) {
    console.error("Signup error:", error)
    return NextResponse.json({ message: error.message || "Something went wrong" }, { status: 500 })
  }
}
