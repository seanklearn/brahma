import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password, redirectTo } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const cookieStore = cookies()
    const supabase = createServerClient()

    // Sign in the user
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 401 })
    }

    // Set cookies
    const response = NextResponse.json({
      user: data.user,
      session: {
        ...data.session,
        access_token: "[REDACTED]",
        refresh_token: "[REDACTED]",
      },
      redirectTo: redirectTo || "/dashboard",
    })

    // Return the session and user
    return response
  } catch (error: any) {
    console.error("Direct login error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
