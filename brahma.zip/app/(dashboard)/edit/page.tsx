"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ProfileHeader } from "@/components/profile-header"
import { SocialLink } from "@/components/social-link"
import { Instagram, Linkedin, TiktokIcon } from "@/components/social-icons"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Trash2, LogOut } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/hooks/use-auth"
import { createBrowserClient } from "@/lib/supabase"

interface SocialLinkType {
  id: string
  platform: string
  url: string
  label: string
  display_order: number
  className?: string
}

const platformIcons: Record<string, any> = {
  instagram: Instagram,
  tiktok: TiktokIcon,
  linkedin: Linkedin,
}

const platformStyles: Record<string, string> = {
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 hover:from-purple-600 hover:to-pink-600",
  tiktok: "bg-black text-white border-0 hover:bg-gray-800",
  linkedin: "bg-blue-600 text-white border-0 hover:bg-blue-700",
  snapchat: "bg-yellow-400 text-black border-0 hover:bg-yellow-500",
  custom: "bg-gray-200 dark:bg-gray-700",
}

export default function EditPage() {
  const { user, signOut } = useAuth()
  const supabase = createBrowserClient()

  const [profile, setProfile] = useState({
    username: "",
    name: "",
    bio: "",
    tagline: "",
    avatar_url: "/placeholder.svg?height=96&width=96",
  })
  const [links, setLinks] = useState<SocialLinkType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [saveStatus, setSaveStatus] = useState("")

  useEffect(() => {
    const fetchUserData = async () => {
      if (!user) return

      try {
        // Fetch profile
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single()

        if (profileError) throw profileError

        setProfile({
          username: profileData.username,
          name: profileData.name,
          bio: profileData.bio || "",
          tagline: profileData.tagline || "",
          avatar_url: profileData.avatar_url || "/placeholder.svg?height=96&width=96",
        })

        // Fetch links
        const { data: linksData, error: linksError } = await supabase
          .from("links")
          .select("*")
          .eq("user_id", user.id)
          .order("display_order", { ascending: true })

        if (linksError) throw linksError

        if (linksData.length === 0) {
          // Create default links if none exist
          const defaultLinks = [
            {
              user_id: user.id,
              platform: "instagram",
              url: `https://instagram.com/${profileData.username}`,
              label: "Instagram",
              display_order: 0,
            },
            {
              user_id: user.id,
              platform: "tiktok",
              url: `https://tiktok.com/@${profileData.username}`,
              label: "TikTok",
              display_order: 1,
            },
            {
              user_id: user.id,
              platform: "snapchat",
              url: `https://snapchat.com/add/${profileData.username}`,
              label: "Snapchat",
              display_order: 2,
            },
          ]

          const { data: insertedLinks, error: insertError } = await supabase.from("links").insert(defaultLinks).select()

          if (insertError) throw insertError

          // Fetch links again after insertion
          const { data: newLinksData, error: newLinksError } = await supabase
            .from("links")
            .select("*")
            .eq("user_id", user.id)
            .order("display_order", { ascending: true })

          if (newLinksError) throw newLinksError

          setLinks(
            newLinksData.map((link: any) => ({
              ...link,
              className: platformStyles[link.platform] || platformStyles.custom,
            })),
          )
        } else {
          setLinks(
            linksData.map((link: any) => ({
              ...link,
              className: platformStyles[link.platform] || platformStyles.custom,
            })),
          )
        }
      } catch (err: any) {
        console.error("Error fetching user data:", err)
        setError("Failed to load your profile data. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    if (user) {
      fetchUserData()
    }
  }, [user, supabase])

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleLinkChange = (id: string, field: string, value: string) => {
    setLinks((prev) => prev.map((link) => (link.id === id ? { ...link, [field]: value } : link)))
  }

  const addLink = () => {
    if (!user) return

    const newLink: SocialLinkType = {
      id: Date.now().toString(), // Temporary ID for UI
      platform: "custom",
      url: "https://",
      label: "New Link",
      display_order: links.length,
      className: platformStyles.custom,
    }
    setLinks((prev) => [...prev, newLink])
  }

  const removeLink = (id: string) => {
    setLinks((prev) => prev.filter((link) => link.id !== id))
  }

  const handleSaveProfile = async () => {
    if (!user) return

    setSaveStatus("Saving profile...")
    setError("")

    try {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          name: profile.name,
          bio: profile.bio,
          tagline: profile.tagline,
          avatar_url: profile.avatar_url,
        })
        .eq("id", user.id)

      if (updateError) throw updateError

      setSaveStatus("Profile saved successfully!")
      setTimeout(() => setSaveStatus(""), 3000)
    } catch (err: any) {
      console.error("Error saving profile:", err)
      setError("Failed to save profile. Please try again.")
      setSaveStatus("")
    }
  }

  const handleSaveLinks = async () => {
    if (!user) return

    setSaveStatus("Saving links...")
    setError("")

    try {
      // First, delete all existing links
      const { error: deleteError } = await supabase.from("links").delete().eq("user_id", user.id)

      if (deleteError) throw deleteError

      // Then insert the updated links
      const linksToInsert = links.map((link, index) => ({
        user_id: user.id,
        platform: link.platform,
        url: link.url,
        label: link.label,
        display_order: index,
      }))

      const { error: insertError } = await supabase.from("links").insert(linksToInsert)

      if (insertError) throw insertError

      // Refresh links with new IDs from the database
      const { data: refreshedLinks, error: refreshError } = await supabase
        .from("links")
        .select("*")
        .eq("user_id", user.id)
        .order("display_order", { ascending: true })

      if (refreshError) throw refreshError

      setLinks(
        refreshedLinks.map((link: any) => ({
          ...link,
          className: platformStyles[link.platform] || platformStyles.custom,
        })),
      )

      setSaveStatus("Links saved successfully!")
      setTimeout(() => setSaveStatus(""), 3000)
    } catch (err: any) {
      console.error("Error saving links:", err)
      setError("Failed to save links. Please try again.")
      setSaveStatus("")
    }
  }

  const handleLogout = async () => {
    await signOut()
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Edit Your Brahma Page</h1>
        <Button variant="outline" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          Log Out
        </Button>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {saveStatus && (
        <Alert className="mb-4">
          <AlertDescription>{saveStatus}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <Tabs defaultValue="profile">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="links">Links</TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>Update your profile details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username (cannot be changed)</Label>
                    <Input id="username" value={profile.username} disabled />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">Display Name</Label>
                    <Input id="name" name="name" value={profile.name} onChange={handleProfileChange} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tagline">Tagline</Label>
                    <Input
                      id="tagline"
                      name="tagline"
                      value={profile.tagline}
                      onChange={handleProfileChange}
                      placeholder="A short description that appears under your name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea id="bio" name="bio" value={profile.bio} onChange={handleProfileChange} rows={3} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="avatar_url">Avatar URL</Label>
                    <Input
                      id="avatar_url"
                      name="avatar_url"
                      value={profile.avatar_url}
                      onChange={handleProfileChange}
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveProfile} className="w-full">
                    Save Profile
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="links">
              <Card>
                <CardHeader>
                  <CardTitle>Social Links</CardTitle>
                  <CardDescription>Manage your social media links</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {links.map((link) => (
                    <div key={link.id} className="flex items-center space-x-2">
                      <div className="flex-1">
                        <Input
                          value={link.label}
                          onChange={(e) => handleLinkChange(link.id, "label", e.target.value)}
                          placeholder="Link Label"
                          className="mb-2"
                        />
                        <Input
                          value={link.url}
                          onChange={(e) => handleLinkChange(link.id, "url", e.target.value)}
                          placeholder="https://"
                        />
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeLink(link.id)}>
                        <Trash2 className="h-5 w-5 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
                <CardFooter className="flex flex-col gap-4">
                  <Button onClick={addLink} className="w-full">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add New Link
                  </Button>
                  <Button onClick={handleSaveLinks} className="w-full">
                    Save Links
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-6 text-center">Preview</h2>
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 p-6 max-w-md mx-auto">
            <ProfileHeader
              username={profile.username}
              name={profile.name}
              bio={profile.bio}
              avatarUrl={profile.avatar_url}
            />

            {profile.tagline && <p className="text-center mt-2 text-muted-foreground">{profile.tagline}</p>}

            <div className="mt-6 space-y-4">
              {links.map((link) => (
                <SocialLink
                  key={link.id}
                  href={link.url}
                  icon={platformIcons[link.platform] || Instagram}
                  label={link.label}
                  className={link.className}
                />
              ))}
            </div>

            <div className="pt-8 text-center">
              <p className="text-xs text-muted-foreground">
                Powered by <span className="font-bold">Brahma</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
