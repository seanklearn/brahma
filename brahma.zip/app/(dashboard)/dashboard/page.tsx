"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ProfileHeader } from "@/components/profile-header"
import { SocialLink } from "@/components/social-link"
import { Instagram, Linkedin, TiktokIcon } from "@/components/social-icons"
import { PlusCircle, Edit, Trash2, Save, X } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/hooks/use-auth"
import { createBrowserClient } from "@/lib/supabase"
import { Skeleton } from "@/components/ui/skeleton"

interface SocialLinkType {
  id: string
  platform: string
  url: string
  label: string
  display_order: number
  className?: string
}

const platformIcons: Record<string, any> = {
  instagram: Instagram,
  tiktok: TiktokIcon,
  linkedin: Linkedin,
}

const platformStyles: Record<string, string> = {
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 hover:from-purple-600 hover:to-pink-600",
  tiktok: "bg-black text-white border-0 hover:bg-gray-800",
  linkedin: "bg-blue-600 text-white border-0 hover:bg-blue-700",
  snapchat: "bg-yellow-400 text-black border-0 hover:bg-yellow-500",
  custom: "bg-gray-200 dark:bg-gray-700",
}

export default function DashboardPage() {
  const router = useRouter()
  const { user, loading: authLoading } = useAuth()
  const supabase = createBrowserClient()

  const [profile, setProfile] = useState({
    username: "",
    name: "",
    bio: "",
    tagline: "",
    avatar_url: "/placeholder.svg?height=96&width=96",
  })
  const [links, setLinks] = useState<SocialLinkType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  // Edit states
  const [editingTagline, setEditingTagline] = useState(false)
  const [taglineValue, setTaglineValue] = useState("")
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null)
  const [editingLink, setEditingLink] = useState<SocialLinkType | null>(null)
  const [showAddLink, setShowAddLink] = useState(false)
  const [newLink, setNewLink] = useState<Omit<SocialLinkType, "id" | "display_order">>({
    platform: "custom",
    url: "https://",
    label: "",
    className: platformStyles.custom,
  })

  useEffect(() => {
    if (authLoading) return

    if (!user) {
      router.push("/login")
      return
    }

    const fetchUserData = async () => {
      try {
        // Fetch profile
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single()

        if (profileError) throw profileError

        setProfile({
          username: profileData.username,
          name: profileData.name,
          bio: profileData.bio || "",
          tagline: profileData.tagline || "",
          avatar_url: profileData.avatar_url || "/placeholder.svg?height=96&width=96",
        })

        setTaglineValue(profileData.tagline || "")

        // Fetch links
        const { data: linksData, error: linksError } = await supabase
          .from("links")
          .select("*")
          .eq("user_id", user.id)
          .order("display_order", { ascending: true })

        if (linksError) throw linksError

        if (linksData.length === 0) {
          // Create default links if none exist
          const defaultLinks = [
            {
              user_id: user.id,
              platform: "instagram",
              url: `https://instagram.com/${profileData.username}`,
              label: "Instagram",
              display_order: 0,
            },
            {
              user_id: user.id,
              platform: "tiktok",
              url: `https://tiktok.com/@${profileData.username}`,
              label: "TikTok",
              display_order: 1,
            },
            {
              user_id: user.id,
              platform: "snapchat",
              url: `https://snapchat.com/add/${profileData.username}`,
              label: "Snapchat",
              display_order: 2,
            },
          ]

          const { error: insertError } = await supabase.from("links").insert(defaultLinks)

          if (insertError) throw insertError

          // Fetch links again after insertion
          const { data: newLinksData, error: newLinksError } = await supabase
            .from("links")
            .select("*")
            .eq("user_id", user.id)
            .order("display_order", { ascending: true })

          if (newLinksError) throw newLinksError

          setLinks(
            newLinksData.map((link: any) => ({
              ...link,
              className: platformStyles[link.platform] || platformStyles.custom,
            })),
          )
        } else {
          setLinks(
            linksData.map((link: any) => ({
              ...link,
              className: platformStyles[link.platform] || platformStyles.custom,
            })),
          )
        }
      } catch (err: any) {
        console.error("Error fetching user data:", err)
        setError("Failed to load your profile data. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserData()
  }, [user, authLoading, router, supabase])

  const handleSaveTagline = async () => {
    if (!user) return

    try {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          tagline: taglineValue,
        })
        .eq("id", user.id)

      if (updateError) throw updateError

      setProfile((prev) => ({ ...prev, tagline: taglineValue }))
      setEditingTagline(false)
      showSuccess("Tagline updated successfully!")
    } catch (err: any) {
      console.error("Error saving tagline:", err)
      setError("Failed to save tagline. Please try again.")
    }
  }

  const handleCancelTagline = () => {
    setTaglineValue(profile.tagline)
    setEditingTagline(false)
  }

  const handleEditLink = (link: SocialLinkType) => {
    setEditingLinkId(link.id)
    setEditingLink({ ...link })
  }

  const handleSaveLink = async () => {
    if (!user || !editingLink) return

    try {
      const { error: updateError } = await supabase
        .from("links")
        .update({
          platform: editingLink.platform,
          url: editingLink.url,
          label: editingLink.label,
        })
        .eq("id", editingLink.id)

      if (updateError) throw updateError

      setLinks((prev) =>
        prev.map((link) =>
          link.id === editingLink.id
            ? {
                ...editingLink,
                className: platformStyles[editingLink.platform] || platformStyles.custom,
              }
            : link,
        ),
      )

      setEditingLinkId(null)
      setEditingLink(null)
      showSuccess("Link updated successfully!")
    } catch (err: any) {
      console.error("Error saving link:", err)
      setError("Failed to save link. Please try again.")
    }
  }

  const handleCancelEditLink = () => {
    setEditingLinkId(null)
    setEditingLink(null)
  }

  const handleDeleteLink = async (id: string) => {
    if (!user) return

    try {
      const { error: deleteError } = await supabase.from("links").delete().eq("id", id)

      if (deleteError) throw deleteError

      setLinks((prev) => prev.filter((link) => link.id !== id))
      showSuccess("Link deleted successfully!")
    } catch (err: any) {
      console.error("Error deleting link:", err)
      setError("Failed to delete link. Please try again.")
    }
  }

  const handleAddLink = async () => {
    if (!user) return

    try {
      const { data, error: insertError } = await supabase
        .from("links")
        .insert({
          user_id: user.id,
          platform: newLink.platform,
          url: newLink.url,
          label: newLink.label,
          display_order: links.length,
        })
        .select()

      if (insertError) throw insertError

      const addedLink = data[0]

      setLinks((prev) => [
        ...prev,
        {
          ...addedLink,
          className: platformStyles[addedLink.platform] || platformStyles.custom,
        },
      ])

      setShowAddLink(false)
      setNewLink({
        platform: "custom",
        url: "https://",
        label: "",
        className: platformStyles.custom,
      })

      showSuccess("Link added successfully!")
    } catch (err: any) {
      console.error("Error adding link:", err)
      setError("Failed to add link. Please try again.")
    }
  }

  const handleCancelAddLink = () => {
    setShowAddLink(false)
    setNewLink({
      platform: "custom",
      url: "https://",
      label: "",
      className: platformStyles.custom,
    })
  }

  const showSuccess = (message: string) => {
    setSuccess(message)
    setTimeout(() => setSuccess(""), 3000)
  }

  if (authLoading || isLoading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex flex-col items-center space-y-4 mb-8">
            <Skeleton className="h-24 w-24 rounded-full" />
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-48" />
            <Skeleton className="h-4 w-72" />
          </div>

          <div className="space-y-4 mt-8">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="flex flex-col items-center space-y-4 mb-8">
          <ProfileHeader
            username={profile.username}
            name={profile.name}
            bio={profile.bio}
            avatarUrl={profile.avatar_url}
          />

          {editingTagline ? (
            <div className="w-full max-w-md flex items-center gap-2">
              <Input
                value={taglineValue}
                onChange={(e) => setTaglineValue(e.target.value)}
                placeholder="Add a tagline..."
                className="flex-1"
              />
              <Button size="icon" variant="ghost" onClick={handleSaveTagline}>
                <Save className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="ghost" onClick={handleCancelTagline}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <p className="text-lg font-medium">{profile.tagline || "Add a tagline to your profile"}</p>
              <Button size="icon" variant="ghost" onClick={() => setEditingTagline(true)}>
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Your Links</h2>
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <Link href="/edit">
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Link>
            </Button>
            <Button onClick={() => setShowAddLink(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Link
            </Button>
          </div>
        </div>

        <Card className="mb-6">
          <CardContent className="p-4">
            {showAddLink && (
              <div className="border p-4 rounded-lg mb-4">
                <h3 className="font-medium mb-2">Add New Link</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium mb-1 block">Platform</label>
                    <select
                      value={newLink.platform}
                      onChange={(e) => setNewLink({ ...newLink, platform: e.target.value })}
                      className="w-full p-2 border rounded-md bg-background"
                    >
                      <option value="instagram">Instagram</option>
                      <option value="tiktok">TikTok</option>
                      <option value="snapchat">Snapchat</option>
                      <option value="linkedin">LinkedIn</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">Label</label>
                    <Input
                      value={newLink.label}
                      onChange={(e) => setNewLink({ ...newLink, label: e.target.value })}
                      placeholder="Link Label"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">URL</label>
                    <Input
                      value={newLink.url}
                      onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                      placeholder="https://"
                    />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={handleCancelAddLink}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddLink}>Add Link</Button>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              {links.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">
                  You don't have any links yet. Add your first link!
                </p>
              ) : (
                links.map((link) => (
                  <div key={link.id} className="relative">
                    {editingLinkId === link.id ? (
                      <div className="border p-4 rounded-lg">
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm font-medium mb-1 block">Platform</label>
                            <select
                              value={editingLink?.platform}
                              onChange={(e) => setEditingLink({ ...editingLink!, platform: e.target.value })}
                              className="w-full p-2 border rounded-md bg-background"
                            >
                              <option value="instagram">Instagram</option>
                              <option value="tiktok">TikTok</option>
                              <option value="snapchat">Snapchat</option>
                              <option value="linkedin">LinkedIn</option>
                              <option value="custom">Custom</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-sm font-medium mb-1 block">Label</label>
                            <Input
                              value={editingLink?.label}
                              onChange={(e) => setEditingLink({ ...editingLink!, label: e.target.value })}
                              placeholder="Link Label"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium mb-1 block">URL</label>
                            <Input
                              value={editingLink?.url}
                              onChange={(e) => setEditingLink({ ...editingLink!, url: e.target.value })}
                              placeholder="https://"
                            />
                          </div>
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" onClick={handleCancelEditLink}>
                              Cancel
                            </Button>
                            <Button onClick={handleSaveLink}>Save</Button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="group relative">
                        <SocialLink
                          href={link.url}
                          icon={platformIcons[link.platform] || Instagram}
                          label={link.label}
                          className={link.className}
                        />
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button size="icon" variant="ghost" onClick={() => handleEditLink(link)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="icon" variant="ghost" onClick={() => handleDeleteLink(link.id)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center">
          <Button asChild variant="outline">
            <Link href={`/${profile.username}`} target="_blank">
              View Your Public Page
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
