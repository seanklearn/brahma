"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createBrowserClient } from "@/lib/supabase"
import Link from "next/link"

export default function SimpleEditPage() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState({
    name: "",
    username: "",
    bio: "",
    tagline: "",
    avatar_url: "",
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const supabase = createBrowserClient()

  useEffect(() => {
    const getUser = async () => {
      try {
        // Get the current user
        const { data: userData, error: userError } = await supabase.auth.getUser()

        if (userError) throw userError

        if (!userData.user) {
          setError("Not authenticated. Please log in.")
          setLoading(false)
          return
        }

        setUser(userData.user)

        // Get the user's profile
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", userData.user.id)
          .single()

        if (profileError) {
          console.error("Profile error:", profileError)
          setError("Failed to load profile data")
        } else {
          setProfile({
            name: profileData.name || "",
            username: profileData.username || "",
            bio: profileData.bio || "",
            tagline: profileData.tagline || "",
            avatar_url: profileData.avatar_url || "",
          })
        }
      } catch (err: any) {
        console.error("Error fetching user:", err)
        setError(err.message || "Failed to load user data")
      } finally {
        setLoading(false)
      }
    }

    getUser()
  }, [supabase])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = async () => {
    if (!user) return

    setSaving(true)
    setError("")
    setSuccess("")

    try {
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          name: profile.name,
          bio: profile.bio,
          tagline: profile.tagline,
          avatar_url: profile.avatar_url,
        })
        .eq("id", user.id)

      if (updateError) throw updateError

      setSuccess("Profile updated successfully!")
    } catch (err: any) {
      console.error("Error updating profile:", err)
      setError(err.message || "Failed to update profile")
    } finally {
      setSaving(false)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    window.location.href = "/login-direct"
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  if (error && !user) {
    return (
      <div className="container mx-auto py-8 px-4">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6">
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error || "Not authenticated"}</AlertDescription>
            </Alert>
            <Button asChild className="w-full">
              <Link href="/login-direct">Go to Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>Edit Profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 bg-green-100 text-green-800">
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="username">Username (cannot be changed)</Label>
            <Input id="username" name="username" value={profile.username} disabled />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Display Name</Label>
            <Input id="name" name="name" value={profile.name} onChange={handleChange} placeholder="Your display name" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tagline">Tagline</Label>
            <Input
              id="tagline"
              name="tagline"
              value={profile.tagline}
              onChange={handleChange}
              placeholder="A short description that appears under your name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              name="bio"
              value={profile.bio}
              onChange={handleChange}
              placeholder="Tell people about yourself"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="avatar_url">Avatar URL</Label>
            <Input
              id="avatar_url"
              name="avatar_url"
              value={profile.avatar_url}
              onChange={handleChange}
              placeholder="URL to your profile picture"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="flex gap-4">
            <Button asChild variant="outline">
              <Link href="/simple-dashboard">Back to Dashboard</Link>
            </Button>
            <Button variant="destructive" onClick={handleSignOut}>
              Sign Out
            </Button>
          </div>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
