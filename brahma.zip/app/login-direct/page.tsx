"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createBrowserClient } from "@/lib/supabase"

export default function DirectLoginPage() {
  const [email, setEmail] = useState("john@example.com")
  const [password, setPassword] = useState("password123")
  const [loading, setLoading] = useState(false)
  const [creatingUser, setCreatingUser] = useState(false)
  const [error, setError] = useState("")
  const [debug, setDebug] = useState<any>(null)
  const [success, setSuccess] = useState(false)

  const handleLogin = async () => {
    setLoading(true)
    setError("")
    setDebug(null)
    setSuccess(false)

    try {
      const supabase = createBrowserClient()

      // Sign in with email and password
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (signInError) {
        console.error("Sign in error details:", signInError)
        throw signInError
      }

      if (!data.session) {
        throw new Error("No session returned after login")
      }

      // Debug info
      setDebug({
        user: data.user,
        session: {
          ...data.session,
          access_token: data.session?.access_token ? "[REDACTED]" : null,
        },
      })

      setSuccess(true)
    } catch (err: any) {
      console.error("Login error:", err)
      setError(err.message || "Failed to log in")
    } finally {
      setLoading(false)
    }
  }

  const createTestUser = async () => {
    setCreatingUser(true)
    setError("")
    setDebug(null)

    try {
      // Call the API route to create a test user
      const response = await fetch(
        `/api/create-test-user?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
      )
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create test user")
      }

      setDebug(data)

      if (data.message === "User already exists") {
        setSuccess(true)
      } else {
        // Try to log in with the newly created user
        await handleLogin()
      }
    } catch (err: any) {
      console.error("Error creating test user:", err)
      setError(err.message || "Failed to create test user")
    } finally {
      setCreatingUser(false)
    }
  }

  const goToDashboard = () => {
    window.location.href = "/simple-dashboard"
  }

  const checkAuthStatus = async () => {
    setLoading(true)
    setError("")

    try {
      const supabase = createBrowserClient()
      const { data, error } = await supabase.auth.getSession()

      if (error) throw error

      setDebug({
        session: data.session
          ? {
              ...data.session,
              access_token: "[REDACTED]",
              refresh_token: "[REDACTED]",
            }
          : null,
        hasSession: !!data.session,
      })

      if (data.session) {
        setSuccess(true)
      } else {
        setError("No active session found")
      }
    } catch (err: any) {
      console.error("Error checking auth status:", err)
      setError(err.message || "Failed to check auth status")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Direct Login</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 bg-green-100 text-green-800">
              <AlertDescription>Login successful! You can now go to the dashboard.</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="john@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password123"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Button className="w-full" onClick={handleLogin} disabled={loading || creatingUser}>
              {loading ? "Logging in..." : "Log In"}
            </Button>

            <Button className="w-full" variant="outline" onClick={createTestUser} disabled={loading || creatingUser}>
              {creatingUser ? "Creating user..." : "Create Test User"}
            </Button>

            <Button className="w-full" variant="secondary" onClick={checkAuthStatus} disabled={loading || creatingUser}>
              Check Auth Status
            </Button>
          </div>

          {success && (
            <Button className="w-full" onClick={goToDashboard}>
              Go to Dashboard
            </Button>
          )}

          {debug && (
            <div className="mt-4 p-2 bg-gray-100 rounded-md">
              <p className="text-sm font-bold">Debug Info:</p>
              <pre className="text-xs overflow-auto max-h-40">{JSON.stringify(debug, null, 2)}</pre>
            </div>
          )}

          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">Instructions:</p>
            <ol className="text-xs text-muted-foreground space-y-1 list-decimal pl-4">
              <li>First click "Create Test User" to ensure a user exists</li>
              <li>Then click "Log In" to authenticate</li>
              <li>If successful, click "Go to Dashboard"</li>
              <li>If you encounter errors, check the debug information</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
