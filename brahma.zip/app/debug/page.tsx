"use client"

import { useEffect, useState } from "react"
import { createBrowserClient } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function DebugPage() {
  const [sessionData, setSessionData] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const supabase = createBrowserClient()

  const checkSession = async () => {
    try {
      const { data, error } = await supabase.auth.getSession()
      if (error) throw error
      setSessionData(data)
    } catch (err: any) {
      setError(err.message)
    }
  }

  useEffect(() => {
    checkSession()
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    window.location.href = "/"
  }

  const handleForceRedirect = () => {
    window.location.href = "/dashboard"
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-3xl mx-auto">
        <CardHeader>
          <CardTitle>Authentication Debug</CardTitle>
          <CardDescription>Check your current authentication status</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="p-4 bg-red-100 text-red-800 rounded-md">
              <p className="font-bold">Error:</p>
              <p>{error}</p>
            </div>
          )}

          <div>
            <h3 className="font-bold mb-2">Session Status:</h3>
            <pre className="bg-gray-100 p-4 rounded-md overflow-auto max-h-96">
              {JSON.stringify(sessionData, null, 2)}
            </pre>
          </div>

          <div className="flex gap-4">
            <Button onClick={checkSession}>Refresh Session Data</Button>
            {sessionData?.session && (
              <Button onClick={handleSignOut} variant="destructive">
                Sign Out
              </Button>
            )}
            <Button onClick={handleForceRedirect} variant="outline">
              Force Redirect to Dashboard
            </Button>
          </div>

          <div className="mt-8 border-t pt-4">
            <h3 className="font-bold mb-2">Troubleshooting Steps:</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Check if you have a valid session above</li>
              <li>If no session, try logging in again</li>
              <li>Clear your browser cookies and try again</li>
              <li>Try using a different browser</li>
              <li>Check browser console for any errors</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
