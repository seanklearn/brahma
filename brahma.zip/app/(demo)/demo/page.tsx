import { ProfileHeader } from "@/components/profile-header"
import { SocialLink } from "@/components/social-link"
import { Instagram, Linkedin, TiktokIcon } from "@/components/social-icons"
import { getUserByUsername } from "@/lib/auth"

const platformIcons: Record<string, any> = {
  instagram: Instagram,
  tiktok: TiktokIcon,
  linkedin: Linkedin,
}

const platformStyles: Record<string, string> = {
  instagram: "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 hover:from-purple-600 hover:to-pink-600",
  tiktok: "bg-black text-white border-0 hover:bg-gray-800",
  linkedin: "bg-blue-600 text-white border-0 hover:bg-blue-700",
  custom: "bg-gray-200 dark:bg-gray-700",
}

export default async function DemoPage() {
  // Try to get the demo user from the database
  const demoUser = await getUserByUsername("demo")

  // If demo user doesn't exist, use fallback demo data
  if (!demoUser) {
    // Fallback demo data
    const fallbackDemo = {
      username: "demo",
      name: "Demo User",
      bio: "This is a demo account to showcase the Brahma app features.",
      avatar_url: "/placeholder.svg?height=96&width=96",
      links: [
        {
          id: "1",
          platform: "instagram",
          url: "https://instagram.com/demo",
          label: "Instagram",
        },
        {
          id: "2",
          platform: "tiktok",
          url: "https://tiktok.com/@demo",
          label: "TikTok",
        },
        {
          id: "3",
          platform: "linkedin",
          url: "https://linkedin.com/in/demo",
          label: "LinkedIn",
        },
      ],
    }

    return (
      <div className="flex flex-col min-h-screen items-center p-4 md:p-8">
        <div className="w-full max-w-md mx-auto py-8 space-y-8">
          <ProfileHeader
            username={fallbackDemo.username}
            name={fallbackDemo.name}
            bio={fallbackDemo.bio}
            avatarUrl={fallbackDemo.avatar_url}
          />

          <div className="space-y-4">
            {fallbackDemo.links.map((link: any, index: number) => (
              <SocialLink
                key={index}
                href={link.url}
                icon={platformIcons[link.platform] || Instagram}
                label={link.label}
                className={platformStyles[link.platform] || platformStyles.custom}
              />
            ))}
          </div>

          <div className="pt-8 text-center">
            <p className="text-xs text-muted-foreground">
              Powered by <span className="font-bold">Brahma</span>
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen items-center p-4 md:p-8">
      <div className="w-full max-w-md mx-auto py-8 space-y-8">
        <ProfileHeader
          username={demoUser.username}
          name={demoUser.name}
          bio={demoUser.bio || ""}
          avatarUrl={demoUser.avatar_url || "/placeholder.svg?height=96&width=96"}
        />

        <div className="space-y-4">
          {demoUser.links &&
            demoUser.links.map((link: any, index: number) => (
              <SocialLink
                key={index}
                href={link.url}
                icon={platformIcons[link.platform] || Instagram}
                label={link.label}
                className={platformStyles[link.platform] || platformStyles.custom}
              />
            ))}
        </div>

        <div className="pt-8 text-center">
          <p className="text-xs text-muted-foreground">
            Powered by <span className="font-bold">Brahma</span>
          </p>
        </div>
      </div>
    </div>
  )
}
