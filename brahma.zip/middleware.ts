import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(request: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req: request, res })

  // Refresh session if expired
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Protected routes
  const protectedPaths = ["/edit", "/dashboard"]
  const path = new URL(request.url).pathname

  // Check if the current path is a protected path
  const isProtectedPath = protectedPaths.some((pp) => path === pp || path.startsWith(`${pp}/`))

  // For debugging - add a header with auth status
  res.headers.set("x-middleware-cache", "no-cache")
  res.headers.set("x-auth-status", session ? "authenticated" : "unauthenticated")

  if (isProtectedPath) {
    // If no session, redirect to login
    if (!session) {
      console.log(`[Middleware] No session found, redirecting from ${path} to login`)
      // Store the original URL as a search parameter
      const redirectUrl = new URL("/login", request.url)
      redirectUrl.searchParams.set("callbackUrl", path)
      return NextResponse.redirect(redirectUrl)
    }

    console.log(`[Middleware] Session found for user ${session.user.id}, allowing access to ${path}`)
  }

  return res
}

// Only run middleware on protected routes
export const config = {
  matcher: ["/edit", "/dashboard", "/edit/:path*", "/dashboard/:path*"],
}
