import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"

// List of reserved usernames that should not be treated as profile pages
const RESERVED_ROUTES = ["login", "signup", "edit", "demo", "api", "_next", "favicon.ico", "dashboard", "auth"]

export async function getSession() {
  const cookieStore = cookies()
  const supabase = createServerClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session
}

// This is a compatibility function for the old auth.ts
export const auth = async () => {
  return getSession()
}

export async function getUserProfile(userId: string) {
  const supabase = createServerClient()

  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (error) {
    console.error("Error fetching user profile:", error)
    return null
  }

  return data
}

// Compatibility function for the old getUserById
export async function getUserById(id: string) {
  return getUserProfile(id)
}

export async function getUserByUsername(username: string) {
  // Skip fetching for reserved routes
  if (RESERVED_ROUTES.includes(username)) {
    return null
  }

  const supabase = createServerClient()

  try {
    // First check if the username exists
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("username", username)
      .maybeSingle()

    if (profileError) {
      console.error("Error fetching profile by username:", profileError)
      return null
    }

    if (!profile) {
      return null
    }

    // Then get the links for this user
    const { data: links, error: linksError } = await supabase
      .from("links")
      .select("*")
      .eq("user_id", profile.id)
      .order("display_order", { ascending: true })

    if (linksError) {
      console.error("Error fetching links:", linksError)
      return { ...profile, links: [] }
    }

    return { ...profile, links }
  } catch (error) {
    console.error("Error in getUserByUsername:", error)
    return null
  }
}

export async function getUserLinks(userId: string) {
  const supabase = createServerClient()

  const { data, error } = await supabase
    .from("links")
    .select("*")
    .eq("user_id", userId)
    .order("display_order", { ascending: true })

  if (error) {
    console.error("Error fetching user links:", error)
    return []
  }

  return data
}

// Add the missing functions from the old auth.ts
export async function createUser(userData: {
  name: string
  username: string
  email: string
  password: string
}) {
  const supabase = createServerClient()

  try {
    // Create user in auth.users
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email: userData.email,
      password: userData.password,
      email_confirm: true,
      user_metadata: {
        name: userData.name,
        username: userData.username,
      },
    })

    if (authError) throw authError

    // Create profile for user - explicitly use the service role key
    const { error: profileError } = await supabase.from("profiles").insert({
      id: authUser.user.id,
      username: userData.username,
      name: userData.name,
      bio: "",
      tagline: "",
      avatar_url: "/placeholder.svg?height=96&width=96",
    })

    if (profileError) {
      console.error("Error creating profile:", profileError)
      // If profile creation fails, delete the user
      await supabase.auth.admin.deleteUser(authUser.user.id)
      throw new Error(`Failed to create profile: ${profileError.message}`)
    }

    return {
      id: authUser.user.id,
      name: userData.name,
      email: userData.email,
      username: userData.username,
    }
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}

export async function updateUserProfile(
  userId: string,
  profileData: {
    name?: string
    bio?: string
    tagline?: string
    avatarUrl?: string
  },
) {
  const supabase = createServerClient()

  try {
    const { data, error } = await supabase
      .from("profiles")
      .update({
        name: profileData.name,
        bio: profileData.bio,
        tagline: profileData.tagline,
        avatar_url: profileData.avatarUrl,
      })
      .eq("id", userId)
      .select()
      .single()

    if (error) throw error

    return data
  } catch (error) {
    console.error("Error updating user profile:", error)
    return null
  }
}

export async function updateUserLinks(userId: string, links: any[]) {
  const supabase = createServerClient()

  try {
    // First, delete all existing links
    const { error: deleteError } = await supabase.from("links").delete().eq("user_id", userId)

    if (deleteError) throw deleteError

    // Then insert the updated links
    const linksToInsert = links.map((link, index) => ({
      user_id: userId,
      platform: link.platform,
      url: link.url,
      label: link.label,
      display_order: index,
    }))

    const { error: insertError } = await supabase.from("links").insert(linksToInsert)

    if (insertError) throw insertError

    // Get the updated links
    const { data, error } = await supabase
      .from("links")
      .select("*")
      .eq("user_id", userId)
      .order("display_order", { ascending: true })

    if (error) throw error

    return { ...getUserById(userId), links: data }
  } catch (error) {
    console.error("Error updating user links:", error)
    return null
  }
}
