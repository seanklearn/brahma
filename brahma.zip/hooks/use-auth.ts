"use client"

import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase"
import { useEffect, useState } from "react"
import type { Session, User } from "@supabase/supabase-js"

export function useAuth() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createBrowserClient()

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      console.log("Auth state changed:", _event, session ? "session exists" : "no session")
      setSession(session)
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Initial session fetch
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log("Initial session fetch:", session ? "session exists" : "no session")
      setSession(session)
      setUser(session?.user ?? null)
      setLoading(false)
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [supabase.auth])

  const signIn = async (email: string, password: string) => {
    try {
      console.log("Signing in with:", email)
      const { error, data } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("Sign in error:", error)
        throw error
      }

      if (!data.user) {
        throw new Error("No user returned from sign in")
      }

      console.log("Sign in successful, redirecting to dashboard")

      // Force a refresh of the session
      await supabase.auth.getSession()

      // Use window.location for a full page refresh to ensure middleware picks up the session
      window.location.href = "/dashboard"
      return { success: true }
    } catch (error) {
      console.error("Sign in error:", error)
      throw error
    }
  }

  const signUp = async (email: string, password: string, userData: { name: string; username: string }) => {
    try {
      // First, check if the username is already taken
      const { data: existingUser } = await supabase
        .from("profiles")
        .select("username")
        .eq("username", userData.username)
        .maybeSingle()

      if (existingUser) {
        throw new Error("Username already taken")
      }

      // Use the server API to create the user instead of client-side signup
      // This will handle email confirmation automatically
      const response = await fetch("/api/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: userData.name,
          username: userData.username,
          email,
          password,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to create account")
      }

      const data = await response.json()
      console.log("Signup successful, signing in...")

      // After successful signup, sign in the user
      await signIn(email, password)

      return { success: true }
    } catch (error: any) {
      console.error("Signup error:", error)
      throw error
    }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    // Use window.location for a full page refresh
    window.location.href = "/"
  }

  return {
    user,
    session,
    loading,
    signIn,
    signUp,
    signOut,
  }
}
