import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface ProfileHeaderProps {
  username: string
  name: string
  bio?: string
  tagline?: string
  avatarUrl?: string
}

export function ProfileHeader({ username, name, bio, tagline, avatarUrl }: ProfileHeaderProps) {
  return (
    <div className="flex flex-col items-center space-y-4 text-center">
      <Avatar className="h-24 w-24 border-2 border-primary">
        <AvatarImage src={avatarUrl || "/placeholder.svg"} alt={name} />
        <AvatarFallback>{name.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="space-y-2">
        <h1 className="text-2xl font-bold">{name}</h1>
        <p className="text-sm text-muted-foreground">@{username}</p>
        {tagline && <p className="text-base font-medium">{tagline}</p>}
        {bio && <p className="text-sm max-w-md">{bio}</p>}
      </div>
    </div>
  )
}
