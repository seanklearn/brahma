import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"
import Link from "next/link"

interface SocialLinkProps {
  href: string
  icon: LucideIcon
  label: string
  className?: string
}

export function SocialLink({ href, icon: Icon, label, className }: SocialLinkProps) {
  return (
    <Button
      asChild
      variant="outline"
      className={cn(
        "w-full h-12 px-6 flex items-center justify-center gap-2 text-base font-medium transition-all hover:scale-105",
        className,
      )}
    >
      <Link href={href} target="_blank" rel="noopener noreferrer">
        <Icon className="h-5 w-5" />
        <span>{label}</span>
      </Link>
    </Button>
  )
}
