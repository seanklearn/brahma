"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/hooks/use-auth"

export function NavBar() {
  const { user, signOut, loading } = useAuth()

  return (
    <header className="px-4 lg:px-6 h-14 flex items-center border-b">
      <Link href="/" className="flex items-center justify-center">
        <span className="text-2xl font-bold">Brahma</span>
      </Link>
      <nav className="ml-auto flex gap-4 sm:gap-6">
        <Link href="/demo" className="text-sm font-medium hover:underline underline-offset-4">
          Demo
        </Link>

        {loading ? (
          <span className="text-sm font-medium text-muted-foreground">Loading...</span>
        ) : user ? (
          <>
            <Link href="/dashboard" className="text-sm font-medium hover:underline underline-offset-4">
              Dashboard
            </Link>
            <Link href="/edit" className="text-sm font-medium hover:underline underline-offset-4">
              Edit Profile
            </Link>
            <Button
              variant="ghost"
              className="text-sm font-medium hover:underline underline-offset-4 h-auto p-0"
              onClick={() => signOut()}
            >
              Log Out ({user.email})
            </Button>
          </>
        ) : (
          <>
            <Link href="/login" className="text-sm font-medium hover:underline underline-offset-4">
              Log In
            </Link>
            <Link href="/signup" className="text-sm font-medium hover:underline underline-offset-4">
              Sign Up
            </Link>
          </>
        )}
      </nav>
    </header>
  )
}
